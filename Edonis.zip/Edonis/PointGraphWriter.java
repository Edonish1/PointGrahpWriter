/**This class displays the weekly share value of stockings over the past 6 weeks */
import javax.swing.*;
import java.awt.*;
public class PointGraphWriter extends JPanel
{  private int width=600;
   private int height=300;
   int x_position=100;
   int y_position=190;
   int d=30;
   int diameter=4;
   public PointGraphWriter()
   {     JFrame myFrame = new JFrame();//the constructor constructs the frame
      myFrame.setTitle("Weekly Financial Market Update");
      myFrame.setVisible(true);
      myFrame.setSize(width, height);
      myFrame.setBackground(Color.WHITE);
      myFrame.getContentPane().add(this);
   }
   public void setAxes(int x_position, int y_position, int axis_length, String x_label, String y_label)
   {  x_position=width/4;
      y_position=(height*3)/8;
      axis_length=d;
      x_label="";
      y_label="";
   }
   public void setPoint1(){}
   public void setPoint2(){}
   public void setPoint3(){}
   public void setPoint4(){}
   public void setPoint5(){}
   public void setPoint6(){}
   public void paintComponent(Graphics g)
   { 
     //Here we display the weeks in the x coordinate
      g.drawLine(x_position-5,y_position,x_position+240,y_position);
      g.drawLine(x_position,y_position+5,x_position,y_position-240);
      g.drawString("Java",x_position-10,y_position+15);
      g.drawString("I",x_position+d,y_position+15);
      g.drawString("II",x_position+2*d,y_position+15);
      g.drawString("III",x_position+3*d,y_position+15);
      g.drawString("IV",x_position+4*d,y_position+15);
      g.drawString("V",x_position+5*d,y_position+15);
      g.drawString("VI",x_position+6*d,y_position+15);
     
     //Here we display the numbers in the y coordinate
      g.drawString("27.50",x_position-80,y_position);
      g.drawString("37.80",x_position-80,y_position-d);
      g.drawString("42.50",x_position-80,y_position-2*d);
      g.drawString("52.50",x_position-80,y_position-3*d);
      g.drawString("57.50",x_position-80,y_position-4*d);
      g.drawString("62.50",x_position-80,y_position-5*d);
    
    //Here we set the points in their respective position
      g.setColor(Color.black);
      g.fillOval(x_position+d,y_position-4*d,diameter,diameter);
      g.fillOval(x_position+2*d,y_position-3*d,diameter,diameter);
      g.fillOval(x_position+3*d,y_position-d,diameter,diameter);
      g.fillOval(x_position+4*d,y_position-6*d,diameter,diameter);
      g.fillOval(x_position+5*d,y_position-5*d,diameter,diameter);
      g.fillOval(x_position+6*d,y_position-2*d,diameter,diameter);
     
     //Here we connect the points with a straight line 
      g.setColor(Color.red);
      g.drawLine(x_position+d,y_position-4*d,x_position+2*d,y_position-3*d);
      g.drawLine(x_position+2*d,y_position-3*d,x_position+3*d,y_position-d);
      g.setColor(Color.blue);
      g.drawLine(x_position+3*d,y_position-d,x_position+4*d,y_position-6*d);
      g.setColor(Color.red);
      g.drawLine(x_position+4*d,y_position-6*d,x_position+5*d,y_position-5*d);
      g.drawLine(x_position+5*d,y_position-5*d,x_position+6*d,y_position-2*d);
   }
    
  
}
