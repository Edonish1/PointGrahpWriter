/**Klasa testuese e klases PointGraphWriter*/
public class PointGraphWriterTest
{
   public static void main (String[] args)
   { PointGraphWriter e=new PointGraphWriter();
   }
}