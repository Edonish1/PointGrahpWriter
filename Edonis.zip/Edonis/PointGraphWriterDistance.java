/**This class asks the user to type some values foor v0 and a,and shows the plotted graph with 
distances travelled for time 0,2,4,6,,8,10*/
import java.awt.*;
import javax.swing.*;
import java.text.*;
public class PointGraphWriterDistance extends JPanel
{  int width=600;
   int height =300;
   int x_position=100;
   int y_position=190;
   private double V0; 
   private double a;
   private double d;
   private double d1;
   private double d2;
   private double d3;
   private double d4;
   private double d5;
   int t=0;
   int t1=2;
   int t2=4;
   int t3=6;
   int t4=8;
   int t5=10;
   int diference=30;
   private int diameter=4;
   public void setAxes(int x_position, int y_position, int axis_length, String x_label, String y_label)
   {  x_position=width/4;
      y_position=(height*3)/8;
      axis_length=(int)d;
      x_label="";
      y_label="";
   }
   public void setPoint1(){}
   public void setPoint2(){}
   public void setPoint3(){}
   public void setPoint4(){}
   public void setPoint5(){}
   public void setPoint6(){}
   public PointGraphWriterDistance()//we construct the frame and give the formulas for the respective values of v0 and a,
   {                                //to find the distance travelled by the time t
   
      String input = JOptionPane.showInputDialog("Shtype vleren V0 :");
      String input1 = JOptionPane.showInputDialog("Shtype vleren a :");
      V0 = new Integer(input).intValue();
      a = new Integer(input1).intValue();
      DecimalFormat formatter = new DecimalFormat("0.0");
      d = (V0*t+(1/2)*a*(t*t));
      d1 = (V0*t1+(1/2)*a*(t1*t1));
      d2 = (V0*t2+(1/2)*a*(t2*t2));
      d3 = (V0*t3+(1/2)*a*(t3*t3));
      d4 = (V0*t4+(1/2)*a*(t4*t4));
      d5 = (V0*t5+(1/2)*a*(t5*t5));
   
      JFrame myFrame = new JFrame();
      myFrame.setTitle("Distance graphic");
      myFrame.setVisible(true);
      myFrame.setSize(width, height);
      myFrame.setBackground(Color.WHITE);
      myFrame.getContentPane().add(this);  
    }
 
   public void paintComponent(Graphics g)
   {g.drawLine(x_position-5,y_position,x_position+240,y_position);
      g.drawLine(x_position,y_position+5,x_position,y_position-240);
     //draws the strings of distance d in their x coordinate
      g.drawString(d+"",x_position,y_position+15);
      g.drawString(d1+"",x_position+diference,y_position+15);
      g.drawString(d2+"",x_position+2*diference,y_position+15);
      g.drawString(d3+"",x_position+3*diference,y_position+15);
      g.drawString(d4+"",x_position+4*diference,y_position+15);
      g.drawString(d5+"",x_position+5*diference,y_position+15);
    
    //draws the value of the time t in the y coordinate
      g.drawString("0",(int)(x_position-80),(int)(y_position));
      g.drawString("2",(int)(x_position-80),(int)(y_position-diference));
      g.drawString("4",(int)(x_position-80),(int)(y_position-2*diference));
      g.drawString("6",(int)(x_position-80),(int)(y_position-3*diference));
      g.drawString("8",(int)(x_position-80),(int)(y_position-4*diference));
      g.drawString("10",(int)(x_position-80),(int)(y_position-5*diference));
   
   //fill the points and puts them in their position on the graph
      g.fillOval((int)(x_position),(int)(y_position),diameter,diameter); 
      g.fillOval((int)(x_position+diference),(int)(y_position-diference),diameter,diameter);
      g.fillOval((int)(x_position+diference*2),(int)(y_position-diference*2),diameter,diameter);
      g.fillOval((int)(x_position+diference*3),(int)(y_position-diference*3),diameter,diameter);
      g.fillOval((int)(x_position+diference*4),(int)(y_position-diference*4),diameter,diameter);
      g.fillOval((int)(x_position+diference*5),(int)(y_position-diference*5),diameter,diameter);
   
   //connect the points with a straight line
      g.drawLine((int)(x_position),(int)(y_position),(int)(x_position+diference),(int)(y_position-diference));
      g.drawLine((int)(x_position+diference),(int)  (y_position-diference),(int)(x_position+diference*2),(int)(y_position-2*diference));
      g.drawLine((int)(x_position+diference*2),(int)(y_position-2*diference),(int)(x_position+diference*3),(int)(y_position-3*diference));
      g.drawLine((int)(x_position+diference*3),(int)(y_position-3*diference),(int)(x_position+diference*4),(int)(y_position-4*diference));
      g.drawLine((int)(x_position+diference*4),(int)(y_position-4*diference),(int)(x_position+diference*5),(int)(y_position-5*diference));
   }
}

 