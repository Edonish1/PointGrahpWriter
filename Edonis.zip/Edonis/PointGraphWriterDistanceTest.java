/**Klasa testuese e klases PointGraphWriterDistance*/
public class PointGraphWriterDistanceTest
{  
   public static void main(String[] args)
   { PointGraphWriterDistance obj=new PointGraphWriterDistance();
   }
}